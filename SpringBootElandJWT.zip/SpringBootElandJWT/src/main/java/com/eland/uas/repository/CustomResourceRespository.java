package com.eland.uas.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.eland.uas.entity.Resource;

@Repository
public interface CustomResourceRespository {
	List<Resource> getResourceByPath(String resourcePath);
}
