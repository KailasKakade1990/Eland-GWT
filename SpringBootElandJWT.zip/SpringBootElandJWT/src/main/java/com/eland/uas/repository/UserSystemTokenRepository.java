package com.eland.uas.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eland.uas.entity.UserSystemToken;

public interface UserSystemTokenRepository extends JpaRepository<UserSystemToken, Long>{

	UserSystemToken findByUserUserId(Long userid);
}
