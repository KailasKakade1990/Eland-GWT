package com.eland.uas.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eland.uas.entity.UserSystemResource;

public interface UserSystemsResourceRepository extends JpaRepository<UserSystemResource, Long>, CustomUserSystemResourceRespository{

}
