package com.eland.uas.repository;

import java.math.BigInteger;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.eland.uas.entity.Resource;
import com.eland.uas.entity.Role;
import com.eland.uas.entity.User;
import com.eland.uas.entity.UserSystemsRole;


@Repository
public interface CustomUserSystemRoleRepository {
	List<Role> getRoleBySystemId(Long systemId);
	List<User> getUserBySystemId(Long[] systemRoleIds);
	List<BigInteger> getSystemIdByUserId(Long userId);
	List<User> getUserBySystemRoleId(Long parseLong);
}
