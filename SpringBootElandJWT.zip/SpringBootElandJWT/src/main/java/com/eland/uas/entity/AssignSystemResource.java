package com.eland.uas.entity;

public class AssignSystemResource {

	private String[] systemId;
	private String[] resourceId;
	private Long isUse;
	public String[] getSystemId() {
		return systemId;
	}
	public void setSystemId(String[] systemId) {
		this.systemId = systemId;
	}
	public String[] getResourceId() {
		return resourceId;
	}
	public void setResourceId(String[] resourceId) {
		this.resourceId = resourceId;
	}
	public Long getIsUse() {
		return isUse;
	}
	public void setIsUse(Long isUse) {
		this.isUse = isUse;
	}
}
