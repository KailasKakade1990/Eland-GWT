package com.eland.uas.reqresp;

import java.util.List;

import com.eland.uas.entity.Resource;

public class ResourceResponse {

	private boolean isSuccess;
	private String message;
	private String errorCode;
	private Object getResources;

	public boolean isSuccess() {
		return isSuccess;
	}

	public void setSuccess(boolean isSuccess) {
		this.isSuccess = isSuccess;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	

	public Object getGetResources() {
		return getResources;
	}

	public void setGetAllResources(Object getResources) {
		this.getResources = getResources;
	}

	public void setGetResources(List<Resource> getResources) {
		this.getResources = getResources;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

}
