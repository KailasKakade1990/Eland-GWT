package com.eland.uas.repository;

import java.math.BigInteger;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.eland.uas.entity.SystemsRole;
import com.eland.uas.entity.User;

@Repository
@Transactional(readOnly = true)
public class CustomSystemsRoleRepositoryImpl implements CustomSystemsRoleRepository{

	@PersistenceContext
	EntityManager entityManager;

	@Override
	public List<Long> getEntityBySystemIdWrkGroup(Long systemId, Long roleId) {
		Query query = entityManager.createNativeQuery("select u.system_role_id from system_role u where u.system_id="+systemId+" and u.role_id="+roleId+" ");
		//query.getResultList();
		  return query.getResultList();
	}

	//@Override
//	public List<BigInteger> getSystemRoleIdbySystemId(Long systemId) {
//		Query query = entityManager.createNativeQuery("select u.system_role_id from system_role u where u.system_id="+systemId+"");
//		//query.getResultList();
//		  return query.getResultList();
//	}
}
