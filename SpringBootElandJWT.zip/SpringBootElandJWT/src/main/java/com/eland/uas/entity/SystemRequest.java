package com.eland.uas.entity;

import javax.persistence.Column;

public class SystemRequest {

	private Long systemId;

	private String name;

	private String description;
	
	private Long isUse;

	public Long getSystemId() {
		return systemId;
	}

	public void setSystemId(Long systemId) {
		this.systemId = systemId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Long getIsUse() {
		return isUse;
	}

	public void setIsUse(Long isUse) {
		this.isUse = isUse;
	}

	@Override
	public String toString() {
		return "SystemRequest [systemId=" + systemId + ", name=" + name + ", description=" + description + ", isUse="
				+ isUse + "]";
	}











}
