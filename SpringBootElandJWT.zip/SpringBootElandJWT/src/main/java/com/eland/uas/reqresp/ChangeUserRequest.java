package com.eland.uas.reqresp;

public class ChangeUserRequest {

}
