package com.eland.uas.service;

public interface UserService {

	Long accountNoGeneration(Long maxno);
}
