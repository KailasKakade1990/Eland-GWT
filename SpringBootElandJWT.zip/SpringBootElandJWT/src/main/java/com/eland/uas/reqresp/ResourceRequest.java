package com.eland.uas.reqresp;

public class ResourceRequest {

	private Long resourceId;
	private String path;
	private String description;
	private Long isUse;

	public Long getResourceId() {
		return resourceId;
	}

	public void setResourceId(Long resourceId) {
		this.resourceId = resourceId;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Long getIsUse() {
		return isUse;
	}

	public void setIsUse(Long isUse) {
		this.isUse = isUse;
	}

	@Override
	public String toString() {
		return "ResourceRequest [resourceId=" + resourceId + ", path=" + path + ", description=" + description
				+ ", isUse=" + isUse + "]";
	}

}
