package com.eland.uas.reqrespmodel;

import com.eland.uas.entity.User;

public class UserRoleResponse {

	private User user;
}
