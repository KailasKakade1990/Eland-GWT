package com.eland.uas.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eland.uas.entity.Systems;
import com.eland.uas.entity.SystemsRole;

public interface SystemsRoleRepository extends JpaRepository<SystemsRole, Long>, CustomSystemsRoleRepository {

	//List<SystemsRole> getSystemRoleIdbySystemId(Long systemId);
	SystemsRole findBySystemSystemId(Long systemid);
}
