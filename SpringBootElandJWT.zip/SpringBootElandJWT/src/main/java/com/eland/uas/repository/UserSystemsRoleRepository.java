package com.eland.uas.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eland.uas.entity.UserSystemsRole;

public interface UserSystemsRoleRepository extends JpaRepository<UserSystemsRole, Long>, CustomUserSystemRoleRepository {
	UserSystemsRole findByUserUserId(long userid);
	
}
