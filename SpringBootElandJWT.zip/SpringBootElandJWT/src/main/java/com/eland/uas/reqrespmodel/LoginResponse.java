package com.eland.uas.reqrespmodel;

public class LoginResponse {

	private boolean isSuccess;
	private String message;
	private String code;
	private String accessToken;
	private boolean isOtpUse;
	
	public boolean isSuccess() {
		return isSuccess;
	}
	public void setSuccess(boolean isSuccess) {
		this.isSuccess = isSuccess;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getAccessToken() {
		return accessToken;
	}
	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}
	public boolean isOtpUse() {
		return isOtpUse;
	}
	public void setOtpUse(boolean isOtpUse) {
		this.isOtpUse = isOtpUse;
	}
}
