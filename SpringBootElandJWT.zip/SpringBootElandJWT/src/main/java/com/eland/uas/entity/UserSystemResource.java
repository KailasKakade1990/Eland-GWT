package com.eland.uas.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "user_system_resource")
public class UserSystemResource {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "user_system_resource_id")
	private Long userSystemResourceId;
	@ManyToOne
	@JoinColumn(name = "system_resource_id")
	private SystemsResource systemResource;
	@ManyToOne
	@JoinColumn(name = "user_system_role_id")
	private UserSystemsRole usersystemRole;
	
	public Long getUserSystemResourceId() {
		return userSystemResourceId;
	}
	public void setUserSystemResourceId(Long userSystemResourceId) {
		this.userSystemResourceId = userSystemResourceId;
	}
	
	public SystemsResource getSystemResource() {
		return systemResource;
	}
	public void setSystemResource(SystemsResource systemResource) {
		this.systemResource = systemResource;
	}
	public UserSystemsRole getUsersystemRole() {
		return usersystemRole;
	}
	public void setUsersystemRole(UserSystemsRole usersystemRole) {
		this.usersystemRole = usersystemRole;
	}
	
}
