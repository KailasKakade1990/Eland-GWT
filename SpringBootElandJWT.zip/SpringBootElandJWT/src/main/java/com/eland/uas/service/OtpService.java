package com.eland.uas.service;

import com.eland.uas.entity.Otp;
import com.eland.uas.entity.SystemOtp;
import com.eland.uas.entity.User;

public interface OtpService {

	Otp addOtp(String otp, User user, SystemOtp systemOtp);
}
