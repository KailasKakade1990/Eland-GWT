package com.eland.uas.ssodemo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.eland.uas.entity.Systems;
import com.eland.uas.repository.SystemsRespository;
import com.eland.uas.reqresp.ClientRequest;
import com.eland.uas.reqresp.ClientResponse;

@RestController
@RequestMapping
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class SSOContoller {
	
	@Autowired
	private SystemsRespository repository;
	
	@RequestMapping(value = "/BO", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> getClientIdClientSecretBO(@RequestBody ClientRequest clientRequest){
		
		Systems systemobj=repository.findByName(clientRequest.getSystemname());
		ClientResponse clientResponse=new ClientResponse();
		clientResponse.setClientId(systemobj.getClientId());
		clientResponse.setClientSecret(systemobj.getClientSecret());
		
		return new ResponseEntity<>(clientResponse,HttpStatus.OK);
	}
	// Mail madhe jase aahe na tasech kara okayok ani ok continue
	@RequestMapping(value = "/PO", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> getClientIdClientSecretPO(@RequestBody ClientRequest clientRequest){
		
		Systems systemobj=repository.findByName(clientRequest.getSystemname());
		ClientResponse clientResponse=new ClientResponse();
		clientResponse.setClientId(systemobj.getClientId());
		clientResponse.setClientSecret(systemobj.getClientSecret());
		
		return new ResponseEntity<>(clientResponse,HttpStatus.OK);
	}
	
	@RequestMapping(value = "/CS", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> getClientIdClientSecretCS(@RequestBody ClientRequest clientRequest){
		
		Systems systemobj=repository.findByName(clientRequest.getSystemname());
		ClientResponse clientResponse=new ClientResponse();
		clientResponse.setClientId(systemobj.getClientId());
		clientResponse.setClientSecret(systemobj.getClientSecret());
		
		return new ResponseEntity<>(clientResponse,HttpStatus.OK);
	}
	
	@RequestMapping(value = "/OMS", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> getClientIdClientSecretOMS(@RequestBody ClientRequest clientRequest){
		
		Systems systemobj=repository.findByName(clientRequest.getSystemname());
		ClientResponse clientResponse=new ClientResponse();
		clientResponse.setClientId(systemobj.getClientId());
		clientResponse.setClientSecret(systemobj.getClientSecret());
		
		return new ResponseEntity<>(clientResponse,HttpStatus.OK);
	}
	
	@RequestMapping(value = "/WMS", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> getClientIdClientSecretWMS(@RequestBody ClientRequest clientRequest){
		
		Systems systemobj=repository.findByName(clientRequest.getSystemname());
		ClientResponse clientResponse=new ClientResponse();
		clientResponse.setClientId(systemobj.getClientId());
		clientResponse.setClientSecret(systemobj.getClientSecret());
		
		return new ResponseEntity<>(clientResponse,HttpStatus.OK);
	}
	
	
	
	

	
}
