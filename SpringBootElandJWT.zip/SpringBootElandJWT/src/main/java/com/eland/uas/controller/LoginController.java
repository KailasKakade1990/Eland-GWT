package com.eland.uas.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LoginController {
	private static final Logger logger = LoggerFactory.getLogger(AdminController.class);

	/*@PostMapping("/login")
	public void login() {
	}
*/
}
