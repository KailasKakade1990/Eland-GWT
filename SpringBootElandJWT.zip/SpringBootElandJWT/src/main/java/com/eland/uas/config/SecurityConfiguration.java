package com.eland.uas.config;

/*@Configuration
public class SecurityConfiguration extends WebSecurityConfigurerAdapter {

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.csrf().disable().authorizeRequests().anyRequest().permitAll();
	}

	@Bean
	public BCryptPasswordEncoder encodePassword() {

		return new BCryptPasswordEncoder();

		// return encrypted password in encrypted formated

	}

}*/
