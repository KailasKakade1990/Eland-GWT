package com.eland.uas.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService{

	@Override
	public Long accountNoGeneration(Long maxno) {
		// TODO Auto-generated method stub
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("YYYYddMM");
		
		String lastFourDigits = "";
		 Long increment = null;
		if(maxno!=null) {
			String input =maxno.toString();     //input string
			     //substring containing last 4 characters
			 
			if (input.length() > 4)
			{
			    lastFourDigits = input.substring(input.length() - 4);
			     increment=Long.parseLong(lastFourDigits);
				increment++;
			}
			else
			{
				increment = (long) 1001;
			}
		}else {
			increment = (long) 1001;
		}
		
		
		
		System.out.println(LocalDate.now().format(formatter));
		String accountdate=LocalDate.now().format(formatter);
		
		String accountno=accountdate+increment;
		return Long.parseLong(accountno);
	}

}
