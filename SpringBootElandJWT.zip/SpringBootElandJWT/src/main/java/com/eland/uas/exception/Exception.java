package com.eland.uas.exception;

public class Exception {

}
