package com.eland.uas.controller;

import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.eland.uas.entity.Otp;
import com.eland.uas.entity.SystemOtp;
import com.eland.uas.entity.Systems;
import com.eland.uas.entity.User;
import com.eland.uas.entity.UserSystemToken;
//import com.eland.uas.enitiy.
import com.eland.uas.entity.UserSystemsRole;
import com.eland.uas.passwordutil.PasswordUtil;
import com.eland.uas.repository.OtpRepository;
import com.eland.uas.repository.SystemOtpRepository;
import com.eland.uas.repository.SystemsRespository;
import com.eland.uas.repository.UserSystemTokenRepository;
import com.eland.uas.repository.UserSystemsRoleRepository;
import com.eland.uas.reqresp.LoginResonse;
import com.eland.uas.reqrespmodel.CommonResponse;
import com.eland.uas.security.JwtTokenUtil;
import com.eland.uas.security.JwtUser;
import com.eland.uas.service.OtpService;
import com.eland.uas.service.PreLoginUserService;

@RestController
@RequestMapping
public class AuthenticationController {

	@Value("${jwt.header}")
	private String tokenHeader;

	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private JwtTokenUtil jwtTokenUtil;

	@Autowired
	private PreLoginUserService userService;

	@Autowired
	UserSystemsRoleRepository userSystemRoleRepository;

	@Autowired
	SystemsRespository systemRepository;

	@Autowired
	SystemOtpRepository systemotpRepository;

	@Autowired
	UserSystemTokenRepository userSystemTokenRepository;
	
	@Autowired
	OtpRepository otpRepository;
	@Autowired
	OtpService otpService;

	// @PostMapping("/login")
	@RequestMapping(value = "/getAccessToken", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> login(@RequestBody User user, HttpServletRequest request, HttpServletResponse response,@RequestHeader HttpHeaders headers) {
		System.out.println("Login API Invoked..");
		LoginResonse resp = new LoginResonse();
		HttpHeaders respHeader = new HttpHeaders();
		String clientId=headers.get("clientId").get(0);
		String clientSecret=headers.get("clientSecret").get(0);
//		boolean successStatus = PasswordUtil.matchPassword(pwdReqResp.getOldPassword(), user.getPassword());
		Systems systems=systemRepository.findByClientIdAndClientSecret(clientId, clientSecret);
		
		try {
			Authentication authentication = authenticationManager
					.authenticate(new UsernamePasswordAuthenticationToken(user.getUserLogId(), user.getPassword()));
			final JwtUser userDetails = (JwtUser) authentication.getPrincipal();
			SecurityContextHolder.getContext().setAuthentication(authentication);

			final String token11 = jwtTokenUtil.generateToken(userDetails);
			// response.setHeader("accessToken", token11);
			Long userid = userDetails.getUser().getUserId();
			UserSystemsRole userSystemsRoleobj = userSystemRoleRepository.findByUserUserId(userid);
			if(systems!=null) {
				Long systemId=userSystemsRoleobj.getSystemRole().getSystem().getSystemId();
				SystemOtp systemotp=systemotpRepository.findByIpAddressAndSystemsSystemId(user.getIpaddress(), systemId);
			if(systemotp!=null) {
			
			//Adding to UserSystemToken Table
			UserSystemToken userSystemToken=new UserSystemToken();
			userSystemToken.setAccessToken(token11);
			userSystemToken.setSystems(systems);
			userSystemToken.setUser(userSystemsRoleobj.getUser());
			userSystemTokenRepository.save(userSystemToken);

			byte[] encodedBytesClientID = Base64
					.encodeBase64(userSystemsRoleobj.getSystemRole().getSystem().getClientId().getBytes());
			byte[] encodedBytesClientSecret = Base64
					.encodeBase64(userSystemsRoleobj.getSystemRole().getSystem().getClientSecret().getBytes());

//			 System.out.println("encodedBytes " + new String(encodedBytes));
//			 byte[] decodedBytes = Base64.decodeBase64(encodedBytes);
//			 System.out.println("decodedBytes " + new String(decodedBytes));
			// Encode using base 64 for client id and client secret

			response.setHeader("clientid", userSystemsRoleobj.getSystemRole().getSystem().getClientId());
			response.setHeader("secret", userSystemsRoleobj.getSystemRole().getSystem().getClientSecret());

			Long isOTPUseLong = userSystemsRoleobj.getSystemRole().getSystem().getInOtpUse();
			String isOtpStr = isOTPUseLong.toString();
			// Boolean isOTPUse = Boolean.parseBoolean(isOtpStr);
			SystemOtp systemOtp = systemotpRepository.findByIpAddressAndSystemsSystemId(user.getIpaddress(),
					userSystemsRoleobj.getSystemRole().getSystem().getSystemId());
			if (isOtpStr.equals("1")) {
				Random r = new Random();
				String randomNumber = String.format("%04d", r.nextInt(1000000));
				String htmlData = "Your OTP is :" + randomNumber;
				boolean success = userService.sendEmail(userDetails.getUser().getEmail(), "OTP for Eland UAS",
						htmlData);
				if (success) {
					Otp otpObj = otpService.addOtp(randomNumber.toString(), userSystemsRoleobj.getUser(), systemOtp);
				}

				String ip = "182.71.254.118";
				resp.setSuccess(true);
				resp.setMessage("Otp Generated Success");
				resp.setOtpUse(true);
				resp.setCode("200");
				resp.setAccessToken(token11);
				return ResponseEntity.ok().headers(respHeader).body(resp);
			} else if (isOtpStr.equals("0")) {
				String otpuse = "otp Use false";
				String ip = "182.71.254.118";
				resp.setSuccess(true);
				resp.setMessage("Login Success");
				resp.setCode("200");
				resp.setOtpUse(false);
				resp.setAccessToken(token11);
				respHeader.add("accessToken", token11);
				return ResponseEntity.ok().headers(respHeader).body(resp);
			} else {
				resp.setSuccess(false);
				resp.setMessage("Login not Success");
				resp.setCode("200");
				respHeader.add("accessToken", null);
				return ResponseEntity.ok().headers(respHeader).body(resp);
			}

			}else {
				resp.setSuccess(false);
				resp.setMessage("Invalid IP Address");
				resp.setCode("99");
				respHeader.add("accessToken", "");
				return ResponseEntity.status(200).headers(respHeader).body(resp);
			}
			}else {
				
				resp.setSuccess(false);
				resp.setMessage("Invalid ClientId And Client Secret");
				resp.setCode("99");
				respHeader.add("accessToken", "");
				return ResponseEntity.status(200).headers(respHeader).body(resp);

			}
			
		} catch (Exception e) {
			e.printStackTrace();
			resp.setSuccess(false);
			resp.setMessage("Invalid Credentials");
			resp.setCode("99");
			respHeader.add("accessToken", "");
			return ResponseEntity.status(200).headers(respHeader).body(resp);
		}
	}

}
