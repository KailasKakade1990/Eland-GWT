package com.eland.uas.reqresp;

public class ClientRequest {

	String systemname;

	public String getSystemname() {
		return systemname;
	}

	public void setSystemname(String systemname) {
		this.systemname = systemname;
	}
	
}
