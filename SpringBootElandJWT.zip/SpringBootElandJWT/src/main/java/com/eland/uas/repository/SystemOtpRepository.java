package com.eland.uas.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eland.uas.entity.SystemOtp;

public interface SystemOtpRepository  extends JpaRepository<SystemOtp, Long>{

	SystemOtp findByIpAddressAndSystemsSystemId(String ipaddress, Long systemId);

}
