/*package com.eland.uas.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface UserInfoRequestRespRepository extends JpaRepository<UserInfoRequestResp, Long>{
	
	@Query(value="SELECT email, user_id, is_use, mobile, telephone_no, user_name, apply_end_date, apply_start_date FROM user",nativeQuery=true )
	List<UserInfoRequestResp> findAllList();

}
*/