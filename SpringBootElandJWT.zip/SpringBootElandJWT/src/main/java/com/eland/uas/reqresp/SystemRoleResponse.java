package com.eland.uas.reqresp;

public class SystemRoleResponse {

	private boolean isSuccess;
	private String message;
	private String code;
	private Object systemRole;
	public boolean isSuccess() {
		return isSuccess;
	}
	public void setSuccess(boolean isSuccess) {
		this.isSuccess = isSuccess;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public Object getSystemRole() {
		return systemRole;
	}
	public void setSystemRole(Object systemRole) {
		this.systemRole = systemRole;
	}
	
	
}
